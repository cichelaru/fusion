import { Component, signal } from '@angular/core';
import { ActivityComponent } from '../shared/activity.component';
import { CostExplorerComponent } from '../shared/cost-explorer.component';
import { KbTableComponent } from '../shared/kb-table.component';
import { SystemsComponent } from '../shared/systems.component';
import { UsersComponent } from '../shared/users.component';
import { StateService } from '../../core/state.service';
import { inject } from '@angular/core';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [ActivityComponent, CostExplorerComponent, KbTableComponent, SystemsComponent, UsersComponent],
  template: `
  <div class="sec-title"><h2>Dashboard admin</h2><span class="small">Vizibil doar pentru administrator</span></div>
  <div class="subtabs">
    @for (t of tabs; track t.k) { <button type="button" [class.on]="tab() === t.k" (click)="tab.set(t.k)">{{ t.l }}</button> }
  </div>
  @switch (tab()) {
    @case ('act') { <app-activity title="Activitate platformă" /> }
    @case ('cost') { <app-cost-explorer /> }
    @case ('sys') { <app-systems /> }
    @case ('users') { <app-users /> }
    @case ('kb') { <app-kb-table /> }
  }
  <p style="margin-top:24px"><button class="link-reset" type="button" (click)="state.resetLocal()">Resetează datele salvate local (cereri, intrări noi, roluri)</button></p>`
})
export class AdminComponent {
  state = inject(StateService);
  tab = signal('act');
  tabs = [
    { k: 'act', l: 'Activitate' }, { k: 'cost', l: 'Cost OPEX' }, { k: 'sys', l: 'Conexiuni sisteme' },
    { k: 'users', l: 'Utilizatori și roluri' }, { k: 'kb', l: 'Bază de cunoștințe' }
  ];
}
