import { Component, effect, inject, untracked } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AssistantService } from './core/assistant.service';
import { AuthService, RLAB } from './core/auth.service';
import { DataService } from './core/data.service';
import { StateService } from './core/state.service';
import { initials } from './core/util';
import { KbModalComponent } from './features/shared/kb-modal.component';

const COMPANIES: [string, string][] = [
  ['RER', 'Rețele Electrice (distribuție)'], ['PPE', 'PPC Energie (furnizare)'], ['PPCRO', 'PPC România'],
  ['PRR', 'PPC Renewables'], ['PTR', 'PPC Trading'], ['PBR', 'PPC Blue'], ['PAE', 'PPC Advanced Energy']
];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, KbModalComponent],
  template: `
  @if (data.error()) {
    <div class="loading err">{{ data.error() }}</div>
  } @else if (!data.ready()) {
    <div class="loading">Se încarcă datele locale…</div>
  } @else {
    @if (auth.isLoggedIn()) {
      <header>
        <div class="brand"><img class="flogo" alt="Fusion" src="logo.jpg"><b>Fusion</b></div>
        <nav>
          <a routerLink="/asistent" routerLinkActive="active">Asistent</a>
          <a routerLink="/personal" routerLinkActive="active">Dashboardul meu</a>
          @if (auth.role() === 'owner') { <a routerLink="/owner" routerLinkActive="active">Dashboard owner</a> }
          @if (auth.role() === 'admin') { <a routerLink="/admin" routerLinkActive="active">Dashboard admin</a> }
          <a routerLink="/flux" routerLinkActive="active">Cum funcționează</a>
        </nav>
        <select title="Compania pentru care se prioritizează documentele" style="border-radius:6px;border:0;padding:6px 8px;font-family:inherit;font-size:13px;margin-right:6px" (change)="onCompany($event)">
          @for (c of companies; track c[0]) { <option [value]="c[0]" [selected]="c[0] === state.company()">{{ c[1] }}</option> }
        </select>
        <div class="user">
          <div class="avatar">{{ ini(auth.user().nume) }}</div>
          <div><b>{{ auth.user().nume }}</b><br><span id="uRole" style="opacity:.8">{{ auth.user().zona }} · <span [class]="'pill role-' + auth.role()">{{ rlab[auth.role()] }}</span></span></div>
          <button class="btn ghost sm" type="button" (click)="auth.logout()">Deconectare</button>
        </div>
      </header>
      <div class="demo-strip">Prototip pentru concurs: profilul, contactele, termenele și cifrele sunt <b>date-exemplu</b>. Autentificarea, trimiterea și statusul cererilor sunt simulate. Datele rămân local, în browser (fără backend).</div>
    }
    <main><router-outlet /></main>
    <app-kb-modal />
  }
  <div class="toast" [class.show]="!!state.toastMsg()">{{ state.toastMsg() }}</div>`
})
export class AppComponent {
  data = inject(DataService);
  auth = inject(AuthService);
  state = inject(StateService);
  private assistant = inject(AssistantService);
  companies = COMPANIES;
  rlab = RLAB;
  ini = initials;

  constructor() {
    this.data.load();
    // la schimbarea utilizatorului conversația pornește de la zero
    effect(() => { this.auth.user(); untracked(() => this.assistant.reset()); });
  }

  onCompany(e: Event): void {
    const s = e.target as HTMLSelectElement;
    this.state.company.set(s.value);
    this.state.toast('Documentele pentru ' + s.selectedOptions[0].text + ' apar primele în căutare.');
  }
}
